Applebloom comes upon Twilight Sparkle as Twilight is heading to visit Zecora in the Everfree Forest. After a gentle request, Twilight lets her come along.

If you don't know pony, all you need to know is this:

- ponies get a magical 'cutie mark' symbol on their flank when they discover their life's purpose
- the Everfree Forest is a mysterious and dangerous place

This is ported from a flash game by Donitz released in 2011. The original tracked music was never released that I could find, so for now I opted for no sound. Claude did most of the work here.

I made only one very slight tweak to the difficulty, since the screen size made it a little unfair.

Use joystick 1 to move, and press fire to interact with ponies and objects. You'll start by moving right until you meet Twilight.

The game is short and simple, but still manages some atmosphere! Have fun!
